/*
    jQuery 문법
*/

$(document).ready(function(){
   
});